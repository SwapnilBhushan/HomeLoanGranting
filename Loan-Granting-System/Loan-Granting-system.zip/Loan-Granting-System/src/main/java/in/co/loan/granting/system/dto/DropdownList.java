package in.co.loan.granting.system.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
