package in.co.loan.granting.system.exception;

public class RecordNotFoundException extends Exception
{
	
	public RecordNotFoundException(String msg) {
		super(msg);

	}
}
